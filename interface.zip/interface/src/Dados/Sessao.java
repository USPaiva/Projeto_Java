/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;

import java.sql.*;
import javax.swing.JOptionPane;
import projeto.Banco;

/**
 *
 * @author uriel
 */
public class Sessao {
    //Sessao
    private int IDExame;
    private int IDTratamento;
    private int IDPaciente;
    private String Pre_Dialise;
    private String Pos_Dialise;
    private double MedPerdaPeso;
    private double PesoSeco;
    private String Acesso;
    private String Filtracao;
    private String TesteCapilar;
    private String Pressao;
    private String Intercorrencia;
    //Sessao
    public String Pre_Dialise() {
        return Pre_Dialise;
    }
    public void setPre_Dialise(String pressaoPre) {
        Pre_Dialise = pressaoPre;
    }
    public String getPos_Dialise() {
        return Pos_Dialise;
    }
    public void setPos_Dialise(String pressaoPos) {
        Pos_Dialise = pressaoPos;
    }
    public double getMedPerdaPeso() {
        return MedPerdaPeso;
    }
    public void setMedPerdaPeso(double medPerdaPeso) {
        MedPerdaPeso = medPerdaPeso;
    }
    public double getPesoSeco() {
        return PesoSeco;
    }
    public void setPesoSeco(double pesoSeco) {
        PesoSeco = pesoSeco;
    }
    public String getAcesso() {
        return Acesso;
    }
    public void setAcesso(String acesso) {
        Acesso = acesso;
    }
    public String getFiltracao() {
        return Filtracao;
    }
    public void setFiltracao(String filtracao) {
        Filtracao = filtracao;
    }
    public String getTesteCapilar() {
        return TesteCapilar;
    }
    public void setTesteCapilar(String testeCapilar) {
        TesteCapilar = testeCapilar;
    }
    public void CadastrarSessao (){
        String query = "Call CadSessao(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setInt(1, this.IDTratamento );
            ps.setInt(2,this.IDExame);
            ps.setInt(3, this.IDPaciente);
            ps.setString(4, this.Pre_Dialise);
            ps.setString(5, this.Pos_Dialise);
            ps.setDouble(6, this.MedPerdaPeso);
            ps.setString(7, this.Pressao);
            ps.setDouble(8, this.PesoSeco);
            ps.setString(9, this.Acesso);
            ps.setString(10, this.Filtracao);
            ps.setString(11, this.TesteCapilar);
            ps.setString(12, this.Intercorrencia);
            ps.execute();
          
            ps.close();
            JOptionPane.showMessageDialog(null,"Salvo Com Sucesso.");
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
    }

    /**
     * @return the IDExame
     */
    public int getIDExame() {
        return IDExame;
    }

    /**
     * @param IDExame the IDExame to set
     */
    public void setIDExame(int IDExame) {
        this.IDExame = IDExame;
    }

    /**
     * @return the IDTratamento
     */
    public int getIDTratamento() {
        return IDTratamento;
    }

    /**
     * @param IDTratamento the IDTratamento to set
     */
    public void setIDTratamento(int IDTratamento) {
        this.IDTratamento = IDTratamento;
    }

    /**
     * @return the IDPaciente
     */
    public int getIDPaciente() {
        return IDPaciente;
    }

    /**
     * @param IDPaciente the IDPaciente to set
     */
    public void setIDPaciente(int IDPaciente) {
        this.IDPaciente = IDPaciente;
    }

    /**
     * @return the Pressao
     */
    public String getPressao() {
        return Pressao;
    }

    /**
     * @param Pressao the Pressao to set
     */
    public void setPressao(String Pressao) {
        this.Pressao = Pressao;
    }

    /**
     * @return the Intercorrencia
     */
    public String getIntercorrencia() {
        return Intercorrencia;
    }

    /**
     * @param Intercorrencia the Intercorrencia to set
     */
    public void setIntercorrencia(String Intercorrencia) {
        this.Intercorrencia = Intercorrencia;
    }
}
