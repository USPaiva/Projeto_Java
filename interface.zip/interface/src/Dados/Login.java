/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;
import java.sql.*;
import javax.swing.JOptionPane;
import projeto.Banco;
/**
 *
 * @author uriel
 */
public class Login extends Cargo{
    //login
    private String UserName;
    private String senha;
    private int IDPessoa;
    
    private int permissao;
    public int getpermissao(){
        return permissao;
    }
    public void setpermissao(int permissao){
        this.permissao=permissao;
    }
    
    public int getIDPessoa() {
        return IDPessoa;
    }
    public void setIDPessoa(int iDPessoa) {
        IDPessoa = iDPessoa;
    }
    //login
    public String getUserName(){
        return this.UserName;
    }
    public void setUserName(String UserName){
        this.UserName = UserName;
    }
    public String getSenha(){
        return this.senha;
    }
    public void setSenha(String senha){
        this.senha = senha;
    }
    public void logar (){
        String query = "Select * from login where UserName=? and Senha=? ";
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setString(1, this.getUserName());
            ps.setString(2, this.getSenha());
            ResultSet res = ps.executeQuery();
          
            while (res.next()) {
                //System.out.println(res.getString("Cargo_idCargo"));
                this.setCargo(res.getString("Cargo_idCargo"));
                this.setpermissao(res.getInt("Cargo_idCargo"));
            }
            //System.out.println(this.getCargo());
            ps.close();
        }catch (SQLException se){
            System.out.println(se.getMessage());
        }
    }
    public void CadastrarLogin (){
        System.out.println(this.getIDCargo());
        String query = "Call Cadastro_USER(?, ?, ?, ?)";
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setString(1, this.UserName );
            ps.setString(2, this.senha);
            ps.setInt(3, this.IDPessoa);
            ps.setInt(4, this.getIDCargo());
            ps.execute();
          
            ps.close();
            JOptionPane.showMessageDialog(null,"Salvo Com Sucesso.");
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
    }
}
