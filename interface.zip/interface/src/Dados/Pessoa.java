/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;


import java.sql.*;
import javax.swing.JOptionPane;
import projeto.Banco;

/**
 *
 * @author uriel
 */
public class Pessoa {
    //Pessoa
    private int IDPessoa;
    private String nome;
    private String Sobrenome;
    private long cpf;
    private String RG;
    private String email;
    private String dataNasc;
    private Telefone telefone;
    private Endereco endereco;
    // Pessoa
    public String getSobrenome(){
        return this.Sobrenome;
    }
    public void setSobrenome(String Sobrenome){
        this.Sobrenome= Sobrenome;
    }
    public String getDataNasc() {
        return this.dataNasc;
    }
    public void setDataNasc(String dataNasc){
        this.dataNasc = dataNasc;
    }
    public String getRG(){
        return this.RG;
    }
    public void setRG(String RG){
        this.RG = RG;
    }
    public String getNome(){
        return this.nome;
    }
    public long getCpf(){
        return this.cpf;
    }
    public String getEmail(){
        return this.email;
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    public void setCpf(long cpf){
        this.cpf = cpf;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public void imprimeDadosPessoa(){
        System.out.println(getNome());
        System.out.println(getCpf());
        System.out.println(getEmail());
    }

    /**
     * @return the telefone
     */
    public Telefone getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(Telefone telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the endereco
     */
    public Endereco getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }
    public void CadastrarPessoa (){
        String query = "Call CadPessoa(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setLong(1, getEndereco().getCEP() );
            ps.setString(2, getEndereco().getCidade());
            ps.setString(3, getEndereco().getRua());
            ps.setString(4, getTelefone().getTipoTel());
            ps.setLong(5, getTelefone().getTelefone());
            ps.setString(6, getNome());
            ps.setString(7, getSobrenome());
            ps.setLong(8, getCpf());
            ps.setString(9, getEmail());
            ps.setString(10, getRG());
            ps.setString(11, getDataNasc());
            ps.execute();
          
            ps.close();
            JOptionPane.showMessageDialog(null,"Salvo Com Sucesso.");
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
    }
    public void CadastrarResponsavel (){
        String query = "Call CadResponsavel(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setLong(1, getEndereco().getCEP() );
            ps.setString(2, getEndereco().getCidade());
            ps.setString(3, getEndereco().getRua());
            ps.setString(4, getTelefone().getTipoTel());
            ps.setLong(5, getTelefone().getTelefone());
            ps.setString(6, getNome());
            ps.setString(7, getSobrenome());
            ps.setLong(8, getCpf());
            ps.setString(9, getEmail());
            ps.setString(10, getRG());
            ps.setString(11, getDataNasc());
            ps.execute();
          
            ps.close();
        }catch (SQLException se){
            System.out.println(se.getMessage());
        }
    }

    /**
     * @return the IDPessoa
     */
    public int getIDPessoa() {
        return IDPessoa;
    }

    /**
     * @param IDPessoa the IDPessoa to set
     */
    public void setIDPessoa(int IDPessoa) {
        this.IDPessoa = IDPessoa;
    }
}
