/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;

import java.sql.*;
import javax.swing.JOptionPane;
import projeto.Banco;

/**
 *
 * @author uriel
 */
public class Paciente extends Pessoa {
    //Paciente
    private Long CNS;
    private String Etnia;
    private String profissao;
    private long NumeroProntuario;
    private String EstadoCivil;
    private String PResponsavel;
    private long Responsavelcpf;
    private int IDResponsavel;
    public String getPResponsavel() {
        return PResponsavel;
    }
    public void setPResponsavel(String pResponsavel) {
        PResponsavel = pResponsavel;
    }
    public String getSexo() {
        return Sexo;
    }
    public void setSexo(String sexo) {
        Sexo = sexo;
    }
    private String Sexo;
    //Paciente
    public String getEstadoCivil() {
        return this.EstadoCivil;
    }
    public void setEstadoCivil(String estadoCivil) {
        this.EstadoCivil = estadoCivil;
    }
    public long getNumeroProntuario(){
        return this.NumeroProntuario;
    }
    public void setNumeroProntuario(long NumeroProntuario){
        this.NumeroProntuario = NumeroProntuario;
    }
    public String getProfissao(){
        return this.profissao;
    }
    public void setProfissao(String profissao){
        this.profissao = profissao;
    }
    public String getEtnia(){
        return this.Etnia;
    }
    public void setEtnia(String Etnia){
        this.Etnia = Etnia;
    }
    public Long getCNS(){
        return this.CNS;
    }
    public void setCNS(Long CNS){
        this.CNS = CNS;
    }

    /**
     * @return the Responsavelcpf
     */
    public long getResponsavelcpf() {
        return Responsavelcpf;
    }

    /**
     * @param Responsavelcpf the Responsavelcpf to set
     */
    public void setResponsavelcpf(long Responsavelcpf) {
        this.Responsavelcpf = Responsavelcpf;
    }

    /**
     * @return the IDResponsavel
     */
    public int getIDResponsavel() {
        return IDResponsavel;
    }

    /**
     * @param IDResponsavel the IDResponsavel to set
     */
    public void setIDResponsavel(int IDResponsavel) {
        this.IDResponsavel = IDResponsavel;
    }
    public void CadastrarPaciente (){
        String query = "Call CadPaciente(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setLong(1, getEndereco().getCEP() );
            ps.setString(2, getEndereco().getCidade());
            ps.setString(3, getEndereco().getRua());
            ps.setString(4, getTelefone().getTipoTel());
            ps.setLong(5, getTelefone().getTelefone());
            ps.setString(6, getNome());
            ps.setString(7, getSobrenome());
            ps.setLong(8, getCpf());
            ps.setString(9, getEmail());
            ps.setString(10, getRG());
            ps.setString(11, getDataNasc());
            ps.setLong(12, this.CNS);
            ps.setString(13, this.Etnia);
            ps.setString(14, this.profissao);
            ps.setLong(15, this.NumeroProntuario);
            ps.setString(16, this.EstadoCivil);
            ps.setString(17, this.Sexo);
            ps.execute();
          
            ps.close();
        }catch (SQLException se){
            System.out.println(se.getMessage());
        }
    }
    public void CadastrarPacienteComR (){
        String query = "Call CadPacienteComResp(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setLong(1, getEndereco().getCEP() );
            ps.setString(2, getEndereco().getCidade());
            ps.setString(3, getEndereco().getRua());
            ps.setString(4, getTelefone().getTipoTel());
            ps.setLong(5, getTelefone().getTelefone());
            ps.setString(6, getNome());
            ps.setString(7, getSobrenome());
            ps.setLong(8, getCpf());
            ps.setString(9, getEmail());
            ps.setString(10, getRG());
            ps.setString(11, getDataNasc());
            ps.setLong(12, this.CNS);
            ps.setString(13, this.Etnia);
            ps.setString(14, this.profissao);
            ps.setLong(15, this.NumeroProntuario);
            ps.setString(16, this.EstadoCivil);
            ps.setString(17, this.Sexo);
            ps.setLong(18, this.getResponsavelcpf());
            ps.execute();
          
            ps.close();
            JOptionPane.showMessageDialog(null,"Salvo Com Sucesso.");
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
    }
}
