/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import projeto.Banco;

/**
 *
 * @author uriel
 */
public class DAO_Paciente {
    public List<Paciente> Read(){
        String query = "Select * from buscapaciente";
        List<Paciente> pacientes = new ArrayList<>();
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ResultSet res = ps.executeQuery();
            while (res.next()) {
                Paciente pessoa = new Paciente();
                Endereco endereco = new Endereco();
                Telefone telefone = new Telefone();
                
                pessoa.setIDPessoa(res.getInt("IdPessoa"));
                pessoa.setNome(res.getString("Nome"));
                pessoa.setSobrenome(res.getString("Sobrenome"));
                pessoa.setCpf(res.getLong("CPF"));
                pessoa.setRG(res.getString("RG"));
                pessoa.setEmail(res.getString("email"));
                pessoa.setDataNasc(res.getString("DataNascimento"));
                endereco.setIDEndereco(res.getInt("idEndereco"));
                endereco.setCEP(res.getLong("CEP"));
                endereco.setCidade(res.getString("Cidade"));
                endereco.setRua(res.getString("Rua"));
                telefone.setIDTelefone(res.getInt("idTelefone"));
                telefone.setTipoTel(res.getString("Tipo_Telefone"));
                telefone.setTelefone(res.getLong("Tel"));
                
                pessoa.setEndereco(endereco);
                pessoa.setTelefone(telefone);

                pacientes.add(pessoa);
            }
            //System.out.println(this.getCargo());
            ps.close();
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
        return pacientes;
    }
    public List<Paciente> ReadFromPaciente(String nome, String sobrenome){
        String query = "Select * from buscapaciente where nome LIKE ? and Sobrenome LIKE ?";
        List<Paciente> pacientes = new ArrayList<>();
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setString(1, "%"+nome+"%");
            ps.setString(2, "%"+sobrenome+"%");
            ResultSet res = ps.executeQuery();
            while (res.next()) {
                Paciente pessoa = new Paciente();
                Endereco endereco = new Endereco();
                Telefone telefone = new Telefone();
                
                pessoa.setIDPessoa(res.getInt("IdPessoa"));
                pessoa.setNome(res.getString("Nome"));
                pessoa.setSobrenome(res.getString("Sobrenome"));
                pessoa.setCpf(res.getLong("CPF"));
                pessoa.setRG(res.getString("RG"));
                pessoa.setEmail(res.getString("email"));
                pessoa.setDataNasc(res.getString("DataNascimento"));
                endereco.setIDEndereco(res.getInt("idEndereco"));
                endereco.setCEP(res.getLong("CEP"));
                endereco.setCidade(res.getString("Cidade"));
                endereco.setRua(res.getString("Rua"));
                telefone.setIDTelefone(res.getInt("idTelefone"));
                telefone.setTipoTel(res.getString("Tipo_Telefone"));
                telefone.setTelefone(res.getLong("Tel"));
                
                pessoa.setEndereco(endereco);
                pessoa.setTelefone(telefone);

                pacientes.add(pessoa);
            }
            //System.out.println(this.getCargo());
            ps.close();
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
        return pacientes;
    }
    public void update(Pessoa p) {
        String query= "Call UPDATEPessoa(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setLong(1, p.getEndereco().getCEP() );
            ps.setString(2, p.getEndereco().getCidade());
            ps.setString(3, p.getEndereco().getRua());
            ps.setString(4, p.getTelefone().getTipoTel());
            ps.setLong(5, p.getTelefone().getTelefone());
            ps.setString(6, p.getNome());
            ps.setString(7, p.getSobrenome());
            ps.setLong(8, p.getCpf());
            ps.setString(9, p.getEmail());
            ps.setString(10, p.getRG());
            ps.setString(11, p.getDataNasc());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException se) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + se);
        }
    }
    
    public void delete(Pessoa p) {
        String query= "DELETE FROM pessoa WHERE IDPessoa = ?";
        try {
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setInt(1, p.getIDPessoa());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException se) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + se);

        }
    }
}
