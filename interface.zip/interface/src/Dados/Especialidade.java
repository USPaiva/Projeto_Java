/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import projeto.Banco;

/**
 *
 * @author Uriel
 */
public class Especialidade {
    //Especialidade
    private String Especialidade;
    private int IDEspecialidade;
    public int getIDEspecialidade() {
        return IDEspecialidade;
    }
    public void setIDEspecialidade(int iDEspecialidade) {
        IDEspecialidade = iDEspecialidade;
    }
    
    //Especialidade
    public String getEspecialidade() {
        return Especialidade;
    }
    public void setEspecialidade(String especialidade) {
        Especialidade = especialidade;
    }
    public List<Especialidade> read(){
        String query = "Select * from Especialidade ";
        List<Especialidade> Especialidades = new ArrayList<>();
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ResultSet res = ps.executeQuery();
          
            while (res.next()) {
                Especialidade especialidade = new Especialidade();
                
                especialidade.setIDEspecialidade(res.getInt("idEspecialidade"));
                especialidade.setEspecialidade(res.getString("Especialidade"));

                Especialidades.add(especialidade);
            }
            //System.out.println(this.getCargo());
            ps.close();
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
        return Especialidades;
    }
    public void CadastrarEspecialidade (){
        String query = "Call CadEspecialidade(?)";
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setString(1, this.Especialidade );
            ps.execute();
          
            ps.close();
            JOptionPane.showMessageDialog(null,"Salvo Com Sucesso.");
        }catch (SQLException se){
            System.out.println(se.getMessage());
        }
    }
    @Override
    public String toString(){
        return getEspecialidade();
    }
}
