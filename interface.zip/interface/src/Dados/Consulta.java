/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;

import java.sql.*;
import javax.swing.JOptionPane;
import projeto.Banco;

/**
 *
 * @author uriel
 */
public class Consulta {
    private String horario;
    private String dia;
    private int IDClinica;
    private int IDPaciente;

    /**
     * @return the horario
     */
    public String getHorario() {
        return horario;
    }

    /**
     * @param horario the horario to set
     */
    public void setHorario(String horario) {
        this.horario = horario;
    }

    /**
     * @return the dia
     */
    public String getDia() {
        return dia;
    }

    /**
     * @param dia the dia to set
     */
    public void setDia(String dia) {
        this.dia = dia;
    }

    /**
     * @return the IDClinica
     */
    public int getIDClinica() {
        return IDClinica;
    }

    /**
     * @param IDClinica the IDClinica to set
     */
    public void setIDClinica(int IDClinica) {
        this.IDClinica = IDClinica;
    }

    /**
     * @return the Paciente
     */
    public int getIDPaciente() {
        return IDPaciente;
    }

    /**
     * @param Paciente the Paciente to set
     */
    public void setIDPaciente(int Paciente) {
        this.IDPaciente = Paciente;
    }
    public void CadastrarConsulta (){
        String query = "Call CadConsulta(?, ?, ?, ?)";
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setInt(1, this.IDClinica );
            ps.setInt(2, this.IDPaciente);
            ps.setString(3, this.dia);
            ps.setString(4, this.horario);
            ps.execute();
          
            ps.close();
            
            JOptionPane.showMessageDialog(null,"Salvo Com Sucesso.");
        
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
    }
}
