/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;

import java.sql.*;
import javax.swing.JOptionPane;
import projeto.Banco;

/**
 *
 * @author uriel
 */
public class Exame {
    //Exame
    private String DataPedido;
    private String DataResult;
    private String Tipo;
    private int IDPaciente;
    //Exame
    public String getDataPedido() {
        return DataPedido;
    }
    public void setDataPedido(String dataPedido) {
        DataPedido = dataPedido;
    }
    public String getDataResult() {
        return DataResult;
    }
    public void setDataResult(String dataResult) {
        DataResult = dataResult;
    }
    public String getTipo() {
        return Tipo;
    }
    public void setTipo(String tipo) {
        Tipo = tipo;
    }

    /**
     * @return the IDPaciente
     */
    public int getIDPaciente() {
        return IDPaciente;
    }

    /**
     * @param IDPaciente the IDPaciente to set
     */
    public void setIDPaciente(int IDPaciente) {
        this.IDPaciente = IDPaciente;
    }
    public void CadastrarExame (){
        String query = "Call CadExame(?, ?, ?, ?)";
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setInt(1, this.IDPaciente );
            ps.setString(2, this.Tipo);
            ps.setString(3, this.DataPedido);
            ps.setString(4, this.DataResult);
            ps.execute();
          
            ps.close();
            
            JOptionPane.showMessageDialog(null,"Salvo Com Sucesso.");
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
    }
}
