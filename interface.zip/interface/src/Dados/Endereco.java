/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;

/**
 *
 * @author uriel
 */
public class Endereco {
    //Endereço
    private long CEP;
    private String Cidade;
    private String Rua;
    private int IDEndereco;
    //Endereço
    public long getCEP() {
        return this.CEP;
    }
    public void setCEP(long CEP) {
        this.CEP = CEP;
    }
    public String getCidade() {
        return Cidade;
    }
    public void setCidade(String cidade) {
        Cidade = cidade;
    }
    public String getRua() {
        return Rua;
    }
    public void setRua(String rua) {
        Rua = rua;
    }

    /**
     * @return the IDEndereco
     */
    public int getIDEndereco() {
        return IDEndereco;
    }

    /**
     * @param IDEndereco the IDEndereco to set
     */
    public void setIDEndereco(int IDEndereco) {
        this.IDEndereco = IDEndereco;
    }
}
