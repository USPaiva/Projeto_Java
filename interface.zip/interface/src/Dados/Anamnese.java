/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;

import java.sql.*;
import javax.swing.JOptionPane;
import projeto.Banco;

/**
 *
 * @author uriel
 */
public class Anamnese {
    //Anamnese
    private String DataPrimeiraDialise;
    private String TerminoEstimado;
    private String FatorRH;
    private String DoencaCronica;
    private String Remedios;
    private String Alergia;
    private String CondicaoEspecial;
    private String Status;
    private int IDPaciente;
    //IMC
    private double altura, peso;
    
    //IMC
    public double IMCC(){
        return peso/(altura*altura);
    }
    public double getAltura(){
        return altura;
    }
    public void setAltura(double altura){
        this.altura = altura;
    }
    public double getPeso(){
        return peso;
    }
    public void setPeso(double peso){
        this.peso = peso;
    }
    //Anamnese
    public String getDataPrimeiraDialise() {
        return DataPrimeiraDialise;
    }
    public void setDataPrimeiraDialise(String dataPrimeiraDialise) {
        DataPrimeiraDialise = dataPrimeiraDialise;
    }
    public String getTerminoEstimado() {
        return TerminoEstimado;
    }
    public void setTerminoEstimado(String terminoEstimado) {
        TerminoEstimado = terminoEstimado;
    }
    public String getFatorRH() {
        return FatorRH;
    }
    public void setFatorRH(String fatorRH) {
        FatorRH = fatorRH;
    }
    public String getDoencaCronica() {
        return DoencaCronica;
    }
    public void setDoencaCronica(String doencaCronica) {
        DoencaCronica = doencaCronica;
    }
    public String getRemedios() {
        return Remedios;
    }
    public void setRemedios(String remedios) {
        Remedios = remedios;
    }
    public String getAlergia() {
        return Alergia;
    }
    public void setAlergia(String alergia) {
        Alergia = alergia;
    }
    public String getCondicaoEspecial() {
        return CondicaoEspecial;
    }
    public void setCondicaoEspecial(String condicaoEspecial) {
        CondicaoEspecial = condicaoEspecial;
    }
    public String getStatus() {
        return Status;
    }
    public void setStatus(String status) {
        Status = status;
    }

    /**
     * @return the IDPaciente
     */
    public int getIDPaciente() {
        return IDPaciente;
    }

    /**
     * @param IDPaciente the IDPaciente to set
     */
    public void setIDPaciente(int IDPaciente) {
        this.IDPaciente = IDPaciente;
    }
    public void CadastrarAnamnese() {
        String query = "Call CadAnamnese(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            try (PreparedStatement ps = Banco.getConexao().prepareStatement(query)) {
                ps.setInt(1, this.IDPaciente);
                ps.setString(2, this.DataPrimeiraDialise);
                ps.setString(3, this.TerminoEstimado);
                ps.setString(4, this.FatorRH);
                ps.setString(5, this.DoencaCronica);
                ps.setString(6, this.Remedios);
                ps.setString(7, this.Alergia);
                ps.setDouble(8, IMCC());
                ps.setString(9, this.CondicaoEspecial);
                ps.setString(10, this.Status);
                ps.execute();
                JOptionPane.showMessageDialog(null,"Salvo Com Sucesso.");
            }
            } catch (SQLException se) {
                JOptionPane.showMessageDialog(null,se.getMessage());
            }
    }
}
