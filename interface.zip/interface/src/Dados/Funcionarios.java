/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import projeto.Banco;

/**
 *
 * @author uriel
 */
public class Funcionarios extends Pessoa {

    /**
     * @return the TipoCertificado
     */
    public String getTipoCertificado() {
        return TipoCertificado;
    }

    /**
     * @param TipoCertificado the TipoCertificado to set
     */
    public void setTipoCertificado(String TipoCertificado) {
        this.TipoCertificado = TipoCertificado;
    }
    //Funcionarios
    private String HoraEntrada;
    private String HoraSaida;
    private String CodigoCertificado;
    
    // Tipo Certificado
    private int IDTipoCertificado;
    private Cargo cargo;
    private String TipoCertificado;
    private Especialidade especialidade;
    
    
    // Tipo Certificado
    public int getIDTipoCertificado() {
        return IDTipoCertificado;
    }
    public void setIDTipoCertificado(int tipoCertificado) {
        IDTipoCertificado = tipoCertificado;
    }
    //Funcionarios
    public String getHoraEntrada() {
        return HoraEntrada;
    }
    public void setHoraEntrada(String horaEntrada) {
        HoraEntrada = horaEntrada;
    }
    public String getHoraSaida() {
        return HoraSaida;
    }
    public void setHoraSaida(String horaSaida) {
        HoraSaida = horaSaida;
    }
    public String getCodigoCertificado() {
        return CodigoCertificado;
    }
    public void setCodigoCertificado(String codigoCertificado) {
        CodigoCertificado = codigoCertificado;
    }
    public void CadastrarFuncionario (){
        String query = "Call CadFuncionario(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setLong(1, getEndereco().getCEP() );
            ps.setString(2, getEndereco().getCidade());
            ps.setString(3, getEndereco().getRua());
            ps.setString(4, getTelefone().getTipoTel());
            ps.setLong(5, getTelefone().getTelefone());
            ps.setString(6, getNome());
            ps.setString(7, getSobrenome());
            ps.setLong(8, getCpf());
            ps.setString(9, getEmail());
            ps.setString(10, getRG());
            ps.setString(11, getDataNasc());
            ps.setInt(12, getCargo().getIDCargo());
            ps.setInt(13, this.IDTipoCertificado);
            ps.setInt(14, this.getEspecialidade().getIDEspecialidade());
            ps.setString(15, this.CodigoCertificado);
            ps.setString(16, this.HoraEntrada);
            ps.setString(17, this.HoraSaida);
            ps.execute();
          
            ps.close();
            JOptionPane.showMessageDialog(null,"Salvo Com Sucesso.");
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
    }
    
    public List<Funcionarios> readC(){
        String query = "Select * from Tipo_Certificado ";
        List<Funcionarios> Certificados = new ArrayList<>();
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ResultSet res = ps.executeQuery();
          
            while (res.next()) {
                Funcionarios Certificado = new Funcionarios();
                
                Certificado.setIDTipoCertificado(res.getInt("idtipo_Certificado"));
                Certificado.setTipoCertificado(res.getString("Tipo_Certificacao"));

                Certificados.add(Certificado);
            }
            //System.out.println(this.getCargo());
            ps.close();
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
        return Certificados;
    }
    
    
    /**
     * @return the cargo
     */
    public Cargo getCargo() {
        return cargo;
    }

    /**
     * @param cargo the cargo to set
     */
    public void setCargo(Cargo cargo) {
        this.cargo = cargo;
    }
    @Override
    public String toString(){
        return getTipoCertificado();
    }

    /**
     * @return the especialidade
     */
    public Especialidade getEspecialidade() {
        return especialidade;
    }

    /**
     * @param especialidade the especialidade to set
     */
    public void setEspecialidade(Especialidade especialidade) {
        this.especialidade = especialidade;
    }
}
