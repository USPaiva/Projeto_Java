/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import projeto.Banco;

/**
 *
 * @author uriel
 */
public class Telefone {
    // Telefone
    private long Telefone;
    private String TipoTel;
    private int IDTelefone;
    //Telefone   
    public String getTipoTel(){
        return this.TipoTel;
    }
    public void setTipoTel(String Tipotel){
        this.TipoTel = Tipotel;
    }
    public long getTelefone(){
        return this.Telefone;
    }
    public void setTelefone(long Telefone){
        this.Telefone = Telefone;
    }

    /**
     * @return the IDTelefone
     */
    public int getIDTelefone() {
        return IDTelefone;
    }

    /**
     * @param IDTelefone the IDTelefone to set
     */
    public void setIDTelefone(int IDTelefone) {
        this.IDTelefone = IDTelefone;
    }

}
