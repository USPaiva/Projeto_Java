/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;

import java.sql.*;
import javax.swing.JOptionPane;
import projeto.Banco;
/**
 *
 * @author uriel
 */
public class Clinica {
    //Clinica
    private String Nome;
    private String email;
    
    private long CNPj;
    private String RazaoSocial;
    private long IE;
    private Telefone telefone;
    private Endereco endereco;
    //Clinica
    
    
    public String getRazaoSocial() {
        return RazaoSocial;
    }
    public void setRazaoSocial(String razaoSocial) {
        RazaoSocial = razaoSocial;
    }
    public long getIE() {
        return IE;
    }
    public void setIE(long iE) {
        IE = iE;
    }
    public long getCNPj() {
        return CNPj;
    }
    public void setCNPj(long cNPj) {
        CNPj = cNPj;
    }
    public String getNome() {
        return Nome;
    }
    public void setNome(String nome) {
        Nome = nome;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the telefone
     */
    public Telefone getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(Telefone telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the endereco
     */
    public Endereco getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }
    public void CadastrarClinica (){
        String query = "Call CadClinica(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setLong(1, getEndereco().getCEP() );
            ps.setString(2, getEndereco().getCidade());
            ps.setString(3, getEndereco().getRua());
            ps.setString(4, getTelefone().getTipoTel());
            ps.setLong(5, getTelefone().getTelefone());
            ps.setString(6, getNome());
            ps.setLong(7, this.CNPj);
            ps.setString(8, getEmail());
            ps.setString(9, this.RazaoSocial);
            ps.setLong(10, this.IE);
            ps.execute();
          
            ps.close();
            
            JOptionPane.showMessageDialog(null,"Salvo Com Sucesso.");
            
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
    }
    
}
