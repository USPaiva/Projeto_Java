/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import projeto.Banco;

/**
 *
 * @author uriel
 */
public class Cargo {
    //Cargo
    private String Cargo;
    private int IDCargo;
    

    public int getIDCargo() {
        return IDCargo;
    }
    public void setIDCargo(int iDCargo) {
        IDCargo = iDCargo;
    }
    //Cargo
    public String getCargo() {
        return Cargo;
    }
    public void setCargo(String cargo) {
        Cargo = cargo;
    }
    
    @Override
    public String toString(){
        return getCargo();
    }
    
    public List<Cargo> read(){
        String query = "Select * from cargo ";
        List<Cargo> cargos = new ArrayList<>();
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ResultSet res = ps.executeQuery();
          
            while (res.next()) {
                Cargo cargo = new Cargo();
                
                cargo.setIDCargo(res.getInt("idCargo"));
                cargo.setCargo(res.getString("Cargo"));

                cargos.add(cargo);
            }
            //System.out.println(this.getCargo());
            ps.close();
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
        return cargos;
    }
    
}

