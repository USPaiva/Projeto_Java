package Dados;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import projeto.Banco;


public class Aplica_Medicamento {

    //Aplica Medicamento
    private int PreDialise, DuranteDialise, PosDialise;
    private String NomeMedicamento;
    private int IdPaciente, IdExame;

    public int getIdPaciente() {
        return IdPaciente;
    }
    public void setIdPaciente(int idPaciente) {
        IdPaciente = idPaciente;
    }
    public int getIdExame() {
        return IdExame;
    }
    public void setIdExame(int idExame) {
        IdExame = idExame;
    }
    //Aplica Medicamento
    public int getPreDialise() {
        return PreDialise;
    }
    public void setPreDialise(int preDialise) {
        PreDialise = preDialise;
    }
    public int getDuranteDialise() {
        return DuranteDialise;
    }
    public void setDuranteDialise(int duranteDialise) {
        DuranteDialise = duranteDialise;
    }
    public int getPosDialise() {
        return PosDialise;
    }
    public void setPosDialise(int posDialise) {
        PosDialise = posDialise;
    }
    public String getNomeMedicamento() {
        return NomeMedicamento;
    }
    public void setNomeMedicamento(String nomeMedicamento) {
        NomeMedicamento = nomeMedicamento;
    }
    public void CadastrarMedicamento (){
        String query = "Call CadMedicamento(?)";
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setString(1, this.NomeMedicamento );
            ps.execute();
          
            ps.close();
            JOptionPane.showMessageDialog(null,"Salvo Com Sucesso.");
        }catch (SQLException se){
            System.out.println(se.getMessage());
        }
    }
    public void CadastrarTratamento (){
        String query = "Call CadTratamento(?, ?, ?, ?, ?)";
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ps.setInt(1, this.IdPaciente );
            ps.setInt(2, this.IdExame );
            ps.setInt(3, this.PreDialise );
            ps.setInt(4, this.DuranteDialise );
            ps.setInt(5, this.PosDialise );
            ps.execute();
          
            ps.close();
            
            JOptionPane.showMessageDialog(null,"Salvo Com Sucesso.");
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
    }
    @Override
    public String toString(){
        return getNomeMedicamento();
    }
    
    public List<Aplica_Medicamento> read(){
        String query = "Select * from Medicamento ";
        List<Aplica_Medicamento> meds = new ArrayList<>();
        try {     
            PreparedStatement ps = Banco.getConexao().prepareStatement(query);
            ResultSet res = ps.executeQuery();
          
            while (res.next()) {
                Aplica_Medicamento med = new Aplica_Medicamento();
                
                med.setNomeMedicamento(res.getString("Nome_Medicamento"));

                meds.add(med);
            }
            //System.out.println(this.getCargo());
            ps.close();
        }catch (SQLException se){
            JOptionPane.showMessageDialog(null,se.getMessage());
        }
        return meds;
    }
}